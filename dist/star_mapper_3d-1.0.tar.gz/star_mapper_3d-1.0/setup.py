import setuptools
from setuptools import setup

setup(
    name='star_mapper_3d',
    version='1.0',
    packages=setuptools.find_packages(),
)